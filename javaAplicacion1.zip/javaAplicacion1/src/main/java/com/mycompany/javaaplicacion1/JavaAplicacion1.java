/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.javaaplicacion1;

import javax.swing.JOptionPane;

/**
 *
 * @author Alejandro Aleman.
 */
public class JavaAplicacion1 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUI.class.getName());
                     private javax.swing.table.DefaultTableModel modeloTabla;
                     private java.util.List<String[]> listaPersonas = new java.util.ArrayList<>();

    /**
     * Creates new form PersonaGUI
     */
    public JavaAplicacion1() {
        initComponents();
        modeloTabla = new javax.swing.table.DefaultTableModel(
    new Object[][]{},
    new String[]{"NOMBRE", "CORREO", "RAZA", "PROFESION", "SEXO"}
);
jTable1.setModel(modeloTabla);

        
    }                  
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        TITULO = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        NombreP = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        HISTORIA = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        raza = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Trabajo = new javax.swing.JList<>();
        borrar = new javax.swing.JButton();
        bGuardar = new javax.swing.JButton();
        bSalir = new javax.swing.JButton();
        Genero = new javax.swing.JPanel();
        Femenino = new javax.swing.JRadioButton();
        Masculino = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos de personaje"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TITULO.setFont(new java.awt.Font("Stencil", 3, 24)); // NOI18N
        TITULO.setForeground(new java.awt.Color(255, 139, 0));
        TITULO.setText("DUNGEONS AND DRAGONS");
        jPanel1.add(TITULO, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 370, 70));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 139, 0));
        jLabel1.setText("Nombre");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, -1, -1));

        NombreP.setToolTipText("Escribe tu nombre aqui");
        NombreP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                NombrePKeyPressed(evt);
            }
        });
        jPanel1.add(NombreP, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 110, -1));

        HISTORIA.setColumns(20);
        HISTORIA.setRows(5);
        HISTORIA.setToolTipText("Describete aqui (como eres, que te gusta, etc..)");
        jScrollPane1.setViewportView(HISTORIA);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, -1, 120));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 139, 0));
        jLabel2.setText("Historia del personaje");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 139, 0));
        jLabel3.setText("Raza");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, -1, -1));

        raza.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Humano", "Elfo", "Gobblin", "Barbaro", "Nordico", "Mago", " " }));
        raza.setToolTipText("Escoge tu raza");
        jPanel1.add(raza, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, 100, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 139, 0));
        jLabel4.setText("Profesion");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 520, -1, -1));

        Trabajo.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "ASESINO", "LEÑADOR", "MINERO", "AVENTURERO", "GUARDIA", "MEDICO", "EXPLORADOR", "BANDIDO", "TANQUE", "CLERIGO", "HECHICERO", "ALDEANO" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        Trabajo.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        Trabajo.setToolTipText("Selecciona tu profesion");
        jScrollPane2.setViewportView(Trabajo);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 540, 100, 100));

        borrar.setText("Borrar");
        borrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                borrarMouseClicked(evt);
            }
        });
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });
        jPanel1.add(borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 670, -1, -1));

        bGuardar.setText("Guardar");
        bGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bGuardarMouseClicked(evt);
            }
        });
        jPanel1.add(bGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 670, -1, -1));

        bSalir.setText("Salir");
        jPanel1.add(bSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 670, -1, -1));

        Genero.setBorder(javax.swing.BorderFactory.createTitledBorder("Sexo"));
        Genero.setToolTipText("Selecciona tu genero");

        buttonGroup1.add(Femenino);
        Femenino.setText("Femenino");
        Femenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemeninoActionPerformed(evt);
            }
        });

        buttonGroup1.add(Masculino);
        Masculino.setText("Masculino");

        javax.swing.GroupLayout GeneroLayout = new javax.swing.GroupLayout(Genero);
        Genero.setLayout(GeneroLayout);
        GeneroLayout.setHorizontalGroup(
            GeneroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(GeneroLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Femenino)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, GeneroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Masculino)
                .addContainerGap())
        );
        GeneroLayout.setVerticalGroup(
            GeneroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(GeneroLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Masculino, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(Femenino)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(Genero, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 139, 0));
        jLabel5.setText("Correo");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        txtCorreo.setToolTipText("Escribe tu correo aqui");
        jPanel1.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 234, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NOMBRE", "EDAD", "SEXO", "RAZA"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 440, 404, 251));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(435, 38, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/javaaplicacion1/dungeons.jpg"))); // NOI18N
        jLabel7.setOpaque(true);
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, -10, 740, 710));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>                        

    private void borrarMouseClicked(java.awt.event.MouseEvent evt) {                                    
        JOptionPane.showMessageDialog(null, "Esta dentro del evento clic");
        if(evt.getButton()== 1){
        NombreP.setText("");
        HISTORIA.setText("");
        txtCorreo.setText("");
        Trabajo.setSelectedIndex(0);
        raza.setSelectedIndex(0);
        
    JOptionPane.showMessageDialog(this, "Gracias por registrarse, que tenga buen dia 👍.");
    System.exit(0);
};

        
        bGuardar.setEnabled(true);
        }                       

    private void NombrePKeyPressed(java.awt.event.KeyEvent evt) {                                   
        if(evt.getKeyChar()== 'a' ){
        bGuardar.setEnabled(true);    
        }
         
    }                                  

    private void bGuardarMouseClicked(java.awt.event.MouseEvent evt) {                                      
        String nombre = NombreP.getText().trim();
String correo = txtCorreo.getText().trim();
String descripcion = HISTORIA.getText().trim();
String estado = raza.getSelectedItem().toString();
String profesion = Trabajo.getSelectedValue();
String genero = Masculino.isSelected() ? "Masculino" : (Femenino.isSelected() ? "Femenino" : "");

if (nombre.isEmpty() || correo.isEmpty() || descripcion.isEmpty() || profesion == null || genero.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Por favor completa todos los campos.");
    return;
}

// Agregar a la tabla
modeloTabla.addRow(new Object[]{nombre, correo, estado, profesion, genero});

listaPersonas.add(new String[]{nombre, correo, estado, profesion, genero, descripcion});

// Guardar en archivo (muy básico)
try (java.io.FileWriter fw = new java.io.FileWriter("personas.txt", true)) {
    fw.write(nombre + ", " + correo + ", " + estado + ", " + profesion + ", " + genero + ", " + descripcion + "\n");
} catch (java.io.IOException e) {
    JOptionPane.showMessageDialog(this, "Error al guardar el archivo");
}

JOptionPane.showMessageDialog(this, "Registro guardado con éxito.");

    }                                     

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {                                       
        NombreP.setText("");
        HISTORIA.setText("");
        txtCorreo.setText("");
        Trabajo.clearSelection(); // Quita la selección de la JList
        raza.setSelectedIndex(0);
        buttonGroup1.clearSelection(); // Deselecciona los radio buttons
        
        JOptionPane.showMessageDialog(this, "Formulario limpiado, listo para un nuevo personaje.", "Borrar", JOptionPane.INFORMATION_MESSAGE);
    }                                      

    private void FemeninoActionPerformed(java.awt.event.ActionEvent evt) {                                  

    }                                        

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GUI().setVisible(true));
    }

    // Variables declaration - do not modify                     
    private javax.swing.JRadioButton Femenino;
    private javax.swing.JPanel Genero;
    private javax.swing.JTextArea HISTORIA;
    private javax.swing.JRadioButton Masculino;
    private javax.swing.JTextField NombreP;
    private javax.swing.JLabel TITULO;
    private javax.swing.JList<String> Trabajo;
    private javax.swing.JButton bGuardar;
    private javax.swing.JButton bSalir;
    private javax.swing.JButton borrar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> raza;
    private javax.swing.JTextField txtCorreo;
    // End of variables declaration                   
}
